function acionarBotao() {
    // Obtendo os valores dos campos
    var textoNome = document.getElementById('txtNome').value.trim(); // Usando trim() para remover espaços em branco
    var textoSenha = document.getElementById('txtSenha').value.trim();

    // Validação dos campos
    if (textoNome == "") {
        alert("Por favor, preencha o campo Usuário!");
        return; // Interrompe a execução se o campo estiver vazio
    }

    if (textoSenha == "") {
        alert("Por favor, preencha o campo Senha!");
        return; // Interrompe a execução se o campo estiver vazio
    }

    // Se todos os campos estiverem preenchidos
    alert("Login realizado com sucesso!"); // Mensagem de sucesso
    // Aqui você pode adicionar a lógica para redirecionar ou processar o login
    // Exemplo: window.location.href = 'pagina_de_sucesso.html';
}